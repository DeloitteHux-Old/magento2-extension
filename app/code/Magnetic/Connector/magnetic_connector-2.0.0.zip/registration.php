<?php
use \Magento\Framework\Component\ComponentRegistrar;

ComponentRegistrar::register(
	ComponentRegistrar::MODULE, 
	'Magnetic_Connector', 
	__DIR__
);
 ?>
 